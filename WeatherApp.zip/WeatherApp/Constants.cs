﻿namespace WeatherApp
{
    public static class Constants
    {
        public static string OpenWeatherMapEndpoint = "https://rapidapi.com/weatherapi/api/weatherapi-com";
        public static string OpenWeatherMapAPIKey = "adee4d9d26685357054efd2f06359807";

    }
}
